---
layout: page
title: About
permalink: /about/
---

Another minimal style of Jekyll theme for writers.
